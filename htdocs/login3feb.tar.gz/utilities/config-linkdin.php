<?php
$baseURL = 'http://telecomacademy.co.in';
$callbackURL = 'http://telecomacademy.co.in/utilities/linkdin-login.php';
$linkedinApiKey = '75ftmt71j4qbys';
$linkedinApiSecret = 'e8pgRvYSYcnOlISQ';
$linkedinScope = 'r_basicprofile r_emailaddress';
?>